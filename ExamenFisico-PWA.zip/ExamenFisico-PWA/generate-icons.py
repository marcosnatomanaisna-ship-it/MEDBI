from PIL import Image, ImageDraw, ImageFont
import os

sizes = [192, 512]

for size in sizes:
    img = Image.new('RGB', (size, size), color='#0D3D26')
    draw = ImageDraw.Draw(img)
    
    # Draw a simple cross/medical icon
    m = size // 2
    t = size // 8
    pad = size // 5
    
    # Cross
    draw.rectangle([m - t, pad, m + t, size - pad], fill='#22C55E')
    draw.rectangle([pad, m - t, size - pad, m + t], fill='#22C55E')
    
    img.save(f'/home/claude/ExamenFisico-PWA/icons/icon-{size}.png')
    print(f"Created icon-{size}.png")
